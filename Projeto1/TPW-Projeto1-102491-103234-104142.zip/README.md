## Copyrights
 
THEME: Medic | Medical HTML Template
	VERSION: 1.0.0
	AUTHOR: Themefisher
	HOMEPAGE: https://themefisher.com/products/medic-medical-template/
	DEMO: https://demo.themefisher.com/themefisher/medic/
	GITHUB: https://github.com/themefisher/Medic-Bootstrap-Medical-Template
	WEBSITE: https://themefisher.com
	TWITTER: https://twitter.com/themefisher
	FACEBOOK: https://www.facebook.com/themefisher
	
the app is deployed on pythonanywhere at http://tiagosora.pythonanywhere.com/ and at http://pjnp5.pythonanywhere.com/

Admin Account:
username - admin
password - admin123
